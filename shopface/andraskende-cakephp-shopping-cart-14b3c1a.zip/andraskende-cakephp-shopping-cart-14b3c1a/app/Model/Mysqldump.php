<?php
class Mysqldump extends AppModel {

    public $useTable = false;

}